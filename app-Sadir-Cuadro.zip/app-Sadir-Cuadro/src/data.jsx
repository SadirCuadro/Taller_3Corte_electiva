export const usuarios = [
    
  {
    "id": 184,
    "title": "SSRF Test",
    "slug": "ssrf-test",
    "price": 100,
    "description": "SSRF Test Product",
    "category": {
      "id": 1,
      "name": "hp2",
      "slug": "hp2",
      "image": "https://www.google.com/imgres?q=gambar%20admin&imgurl=https%3A%2F%2Fst2.depositphotos.com%2F1071184%2F6467%2Fv%2F450%2Fdepositphotos_64677535-stock-illustration-business-customer-care-service.jpg&imgrefurl=https%3A%2F%2Fdepositphotos.com%2Fid%2Fillustrations%2Fadmin.html&docid=cn69m4kNYq0lRM&tbnid=WvtsGak5gb8fZM&vet=12ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA..i&w=600&h=600&hcb=2&ved=2ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-28T17:50:11.000Z"
    },
    "images": [
      "http://169.254.169.254/latest/meta-data/iam/security-credentials/"
    ],
    "creationAt": "2025-05-28T16:34:56.000Z",
    "updatedAt": "2025-05-28T16:34:56.000Z"
  },
  
  {
    "id": 186,
    "title": "test",
    "slug": "test",
    "price": 1000,
    "description": "lorem test",
    "category": {
      "id": 2,
      "name": "Electronics",
      "slug": "electronics",
      "image": "https://i.imgur.com/ZANVnHE.jpeg",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-27T19:58:17.000Z"
    },
    "images": [
      "https://res.cloudinary.com/dfiui980m/image/upload/v1748450100/jwwchqqp2i0tpqxw6f34.jpg",
      "https://res.cloudinary.com/dfiui980m/image/upload/v1748450106/s36zjsh8rdcsjkfbwphd.jpg"
    ],
    "creationAt": "2025-05-28T16:35:30.000Z",
    "updatedAt": "2025-05-28T16:35:30.000Z"
  },
  {
    "id": 188,
    "title": "Carro",
    "slug": "nombre-unico",
    "price": 100000,
    "description": "the car made for running and having style",
    "category": {
      "id": 1,
      "name": "hp2",
      "slug": "hp2",
      "image": "https://www.google.com/imgres?q=gambar%20admin&imgurl=https%3A%2F%2Fst2.depositphotos.com%2F1071184%2F6467%2Fv%2F450%2Fdepositphotos_64677535-stock-illustration-business-customer-care-service.jpg&imgrefurl=https%3A%2F%2Fdepositphotos.com%2Fid%2Fillustrations%2Fadmin.html&docid=cn69m4kNYq0lRM&tbnid=WvtsGak5gb8fZM&vet=12ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA..i&w=600&h=600&hcb=2&ved=2ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-28T17:50:11.000Z"
    },
    "images": [
      "https://st1.uvnimg.com/dims4/default/0102b2f/2147483647/resize/1093x820%3E/quality/75/?url=http%3A%2F%2Fuvn-brightspot.s3.amazonaws.com%2Fd4%2F4a%2F006304a74db4902c0b4d8d8026c8%2Fchevrolet-corvette-c8-stingray-2020-1280-08.jpg"
    ],
    "creationAt": "2025-05-28T16:47:10.000Z",
    "updatedAt": "2025-05-28T16:47:10.000Z"
  },
  {
    "id": 189,
    "title": "My item222",
    "slug": "my-item222",
    "price": 10,
    "description": "What a nice product",
    "category": {
      "id": 1,
      "name": "hp2",
      "slug": "hp2",
      "image": "https://www.google.com/imgres?q=gambar%20admin&imgurl=https%3A%2F%2Fst2.depositphotos.com%2F1071184%2F6467%2Fv%2F450%2Fdepositphotos_64677535-stock-illustration-business-customer-care-service.jpg&imgrefurl=https%3A%2F%2Fdepositphotos.com%2Fid%2Fillustrations%2Fadmin.html&docid=cn69m4kNYq0lRM&tbnid=WvtsGak5gb8fZM&vet=12ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA..i&w=600&h=600&hcb=2&ved=2ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-28T17:50:11.000Z"
    },
    "images": [
      "https://i.imgur.com/1twoaDy.jpeg",
      "https://i.imgur.com/1twoaDy.jpeg",
      "https://i.imgur.com/1twoaDy.jpeg"
    ],
    "creationAt": "2025-05-28T17:05:41.000Z",
    "updatedAt": "2025-05-28T17:05:41.000Z"
  },
  {
    "id": 191,
    "title": "áo thun",
    "slug": "ao-thun",
    "price": 4,
    "description": "ngon ngot",
    "category": {
      "id": 4,
      "name": "Shoes",
      "slug": "shoes",
      "image": "https://i.imgur.com/qNOjJje.jpeg",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-27T19:58:17.000Z"
    },
    "images": [
      "https://images.unsplash.com/photo-1746647695879-bfab32f59f34?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHwyfHx8ZW58MHx8fHx8"
    ],
    "creationAt": "2025-05-28T17:23:34.000Z",
    "updatedAt": "2025-05-28T17:23:34.000Z"
  },
  {
    "id": 192,
    "title": "RevoShop - American Professional II Stratocaster® HSS",
    "slug": "revoshop-american-professional-ii-stratocaster-hss",
    "price": 1200,
    "description": "The American Professional II Stratocaster® HSS draws from more than sixty years of innovation, inspiration and evolution to meet the demands of today's working player.",
    "category": {
      "id": 1,
      "name": "hp2",
      "slug": "hp2",
      "image": "https://www.google.com/imgres?q=gambar%20admin&imgurl=https%3A%2F%2Fst2.depositphotos.com%2F1071184%2F6467%2Fv%2F450%2Fdepositphotos_64677535-stock-illustration-business-customer-care-service.jpg&imgrefurl=https%3A%2F%2Fdepositphotos.com%2Fid%2Fillustrations%2Fadmin.html&docid=cn69m4kNYq0lRM&tbnid=WvtsGak5gb8fZM&vet=12ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA..i&w=600&h=600&hcb=2&ved=2ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-28T17:50:11.000Z"
    },
    "images": [
      "https://i.imgur.com/lr7597x.png"
    ],
    "creationAt": "2025-05-28T17:35:38.000Z",
    "updatedAt": "2025-05-28T17:35:38.000Z"
  },
  {
    "id": 193,
    "title": "RevoShop - Player II Modified Stratocaster® - Sunburst",
    "slug": "revoshop-player-ii-modified-stratocaster-sunburst",
    "price": 1100,
    "description": "The Player II Modified Stratocaster® is a classic guitar with the modern player in mind. Sunburst finish adds a vintage touch to this modern instrument.",
    "category": {
      "id": 1,
      "name": "hp2",
      "slug": "hp2",
      "image": "https://www.google.com/imgres?q=gambar%20admin&imgurl=https%3A%2F%2Fst2.depositphotos.com%2F1071184%2F6467%2Fv%2F450%2Fdepositphotos_64677535-stock-illustration-business-customer-care-service.jpg&imgrefurl=https%3A%2F%2Fdepositphotos.com%2Fid%2Fillustrations%2Fadmin.html&docid=cn69m4kNYq0lRM&tbnid=WvtsGak5gb8fZM&vet=12ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA..i&w=600&h=600&hcb=2&ved=2ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-28T17:50:11.000Z"
    },
    "images": [
      "https://i.imgur.com/BePqXpr.png"
    ],
    "creationAt": "2025-05-28T17:35:39.000Z",
    "updatedAt": "2025-05-28T17:35:39.000Z"
  },
  {
    "id": 194,
    "title": "RevoShop - Player II Modified Stratocaster® - Pearl",
    "slug": "revoshop-player-ii-modified-stratocaster-pearl",
    "price": 1300,
    "description": "The Player II Modified Stratocaster® is a classic guitar with the modern player in mind. Pearl finish adds a unique touch to this modern instrument.",
    "category": {
      "id": 1,
      "name": "hp2",
      "slug": "hp2",
      "image": "https://www.google.com/imgres?q=gambar%20admin&imgurl=https%3A%2F%2Fst2.depositphotos.com%2F1071184%2F6467%2Fv%2F450%2Fdepositphotos_64677535-stock-illustration-business-customer-care-service.jpg&imgrefurl=https%3A%2F%2Fdepositphotos.com%2Fid%2Fillustrations%2Fadmin.html&docid=cn69m4kNYq0lRM&tbnid=WvtsGak5gb8fZM&vet=12ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA..i&w=600&h=600&hcb=2&ved=2ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-28T17:50:11.000Z"
    },
    "images": [
      "https://i.imgur.com/J9Kpem5.png"
    ],
    "creationAt": "2025-05-28T17:35:39.000Z",
    "updatedAt": "2025-05-28T17:35:39.000Z"
  },
  {
    "id": 195,
    "title": "RevoShop - Tash Sultana Stratocaster®",
    "slug": "revoshop-tash-sultana-stratocaster",
    "price": 1250,
    "description": "Tash Sultana's explosive loop-based performances, gorgeous layered guitar parts and jubilant leads rocketed the Melbourne artist from street busking to sold out shows - with a Fender in hand from the beginning.",
    "category": {
      "id": 1,
      "name": "hp2",
      "slug": "hp2",
      "image": "https://www.google.com/imgres?q=gambar%20admin&imgurl=https%3A%2F%2Fst2.depositphotos.com%2F1071184%2F6467%2Fv%2F450%2Fdepositphotos_64677535-stock-illustration-business-customer-care-service.jpg&imgrefurl=https%3A%2F%2Fdepositphotos.com%2Fid%2Fillustrations%2Fadmin.html&docid=cn69m4kNYq0lRM&tbnid=WvtsGak5gb8fZM&vet=12ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA..i&w=600&h=600&hcb=2&ved=2ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-28T17:50:11.000Z"
    },
    "images": [
      "https://i.imgur.com/NOEQcdi.png"
    ],
    "creationAt": "2025-05-28T17:35:40.000Z",
    "updatedAt": "2025-05-28T17:35:40.000Z"
  },
  {
    "id": 198,
    "title": "casa para relajarse",
    "slug": "new-product",
    "price": 100000,
    "description": "the best house on the planet",
    "category": {
      "id": 1,
      "name": "hp2",
      "slug": "hp2",
      "image": "https://www.google.com/imgres?q=gambar%20admin&imgurl=https%3A%2F%2Fst2.depositphotos.com%2F1071184%2F6467%2Fv%2F450%2Fdepositphotos_64677535-stock-illustration-business-customer-care-service.jpg&imgrefurl=https%3A%2F%2Fdepositphotos.com%2Fid%2Fillustrations%2Fadmin.html&docid=cn69m4kNYq0lRM&tbnid=WvtsGak5gb8fZM&vet=12ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA..i&w=600&h=600&hcb=2&ved=2ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-28T17:50:11.000Z"
    },
    "images": [
      "https://mansionesmiami.com/wp-content/uploads/2019/09/casa-de-lujo-768x509.jpg"
    ],
    "creationAt": "2025-05-28T18:02:21.000Z",
    "updatedAt": "2025-05-28T18:02:21.000Z"
  },
  {
    "id": 199,
    "title": "New1 Product",
    "slug": "new1-product",
    "price": 25000,
    "description": "the best motorcycle in the world",
    "category": {
      "id": 2,
      "name": "Electronics",
      "slug": "electronics",
      "image": "https://i.imgur.com/ZANVnHE.jpeg",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-27T19:58:17.000Z"
    },
    "images": [
      "https://i.pinimg.com/736x/d6/68/c3/d668c39193ff04fd74fcf95b23ec8fbc.jpg"
    ],
    "creationAt": "2025-05-28T18:07:01.000Z",
    "updatedAt": "2025-05-28T18:07:01.000Z"
  }
]